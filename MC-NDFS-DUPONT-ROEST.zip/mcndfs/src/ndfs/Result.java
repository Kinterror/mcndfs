package ndfs;



public class Result extends Throwable {



    private static final long serialVersionUID = 1L;



    public Result(String message) {
        super(message);
    }
}
