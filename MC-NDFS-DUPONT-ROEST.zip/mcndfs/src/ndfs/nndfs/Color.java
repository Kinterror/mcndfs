package ndfs.nndfs;



public enum Color {



    CYAN, WHITE, RED, BLUE
}
