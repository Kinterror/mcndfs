package ndfs;



import graph.State;



public interface NDFS {



    public void ndfs() throws Result;


    public void init();
}
