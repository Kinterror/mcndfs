package ndfs.mcndfs_1_naive;

public enum Color {

    CYAN, WHITE, BLUE
    
}
